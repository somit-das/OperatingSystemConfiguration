# Lotion
A free monospace font for programming!

## Update: more western european language support
![picture of western european glyphs](img/western_european_glyphs.png "Picture of western european glyphs")

