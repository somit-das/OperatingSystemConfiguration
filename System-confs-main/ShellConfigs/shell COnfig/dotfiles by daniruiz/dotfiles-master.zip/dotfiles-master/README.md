 ~/.dotfiles
===============================
# More information at [drasite.com/dotfiles](https://drasite.com/dotfiles)
  
Bear in mind that I use this repository to save my own configuration files, and some of them might not work out of the box for you. If you want a guide about how to customize your terminal on your taste, you can follow this post:  
# Post about terminal customizations: [drasite.com/blog/Pimp my terminal](https://drasite.com/blog/Pimp%20my%20terminal)

<p align="center">
  <a href="https://drasite.com/blog/Pimp%20my%20terminal">
    <img alt="Pimp my terminal post" src="https://raw.githubusercontent.com/daniruiz/dotfiles/master/Screenshots/pimp-my-term.png">
  </a>
</p>
<p align="center">
  <img alt="terminal preview" src="https://raw.githubusercontent.com/daniruiz/dotfiles/master/Screenshots/terminal.png">
</p>
<p align="center">
  <img alt="dotfiles tree" src="https://raw.githubusercontent.com/daniruiz/dotfiles/master/Screenshots/tree.png">
</p>
