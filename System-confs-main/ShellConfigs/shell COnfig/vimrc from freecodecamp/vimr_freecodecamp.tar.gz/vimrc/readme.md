# My .vimrc 


![vimrc_screenshot2](/screenshot2.png)

### Vim 
### Theme: Molokai
### Font: FiraCode Nerd


![vimrc_screenshot1](/screenshot1.png)

### GVim 
### Theme: Gruvbox
### Font: FiraCode Nerd

```
.vim/
├── autoload/
├── backup/
├── colors/
├── undo/
├── spell/
└── templates/
    ├── css.tpl
    └── html.tpl
```
